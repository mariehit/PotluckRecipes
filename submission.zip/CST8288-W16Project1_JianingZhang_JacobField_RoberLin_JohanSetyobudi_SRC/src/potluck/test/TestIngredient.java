package potluck.test;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.assertEquals;
import potluck.domain.Ingredient;
/**
 * 
 * @author Marie
 *
 */
public class TestIngredient {
	private Ingredient ingredient;

	/**
	 * setup before test
	 * @throws Exception
	 */
	@Before
	public void setUp() throws Exception {
		ingredient = new Ingredient("name", "measurement");
	}

	/**
	 * clear up after test
	 * @throws Exception
	 */
	@After
	public void tearDown() throws Exception {
		ingredient = null;
	}

	/**
	 * test name setup in constructor
	 */
	@Test
	public void testConstructorName() {
		assertEquals("name", ingredient.getName());
	}
	
	/**
	 * test measurement setup in constructor
	 */
	@Test
	public void testConstructorMeasurement() {
		assertEquals("measurement", ingredient.getMeasurement());
	}

}

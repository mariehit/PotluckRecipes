package potluck.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import potluck.domain.Category;
import potluck.domain.CategoryName;
/**
 * 
 * @author Marie
 *
 */
public class TestCategory {
	/**
	 * category of recipe
	 */
	private Category category;
	/**
	 * setup before test
	 * @throws Exception
	 */
	@Before
	public void setUp() throws Exception {
		category = new Category(CategoryName.BAKERY);
	}

	/**
	 * clear up after test
	 * @throws Exception
	 */
	@After
	public void tearDown() throws Exception {
		category = null;
	}

	/**
	 * test Category constructor
	 */
	@Test
	public void test() {
		assertEquals(CategoryName.BAKERY, category.getCategoryName());
	}

}

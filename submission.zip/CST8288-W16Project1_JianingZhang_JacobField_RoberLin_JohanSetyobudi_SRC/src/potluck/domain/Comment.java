package potluck.domain;

/**
 * holds all the data for the comment system
 * CST8288
 * @author Jacob Field
 * @version   0.0.0
 * 
 * @since 1.8.0_65
 * March 11/2016
 */

public class Comment {

	/**
	 * comment id
	 */
	private int commentId;
	/**
	 * rank for the recipe from this comment
	 */
	private short rank;
	/**
	 * date of the comment created
	 */
	private String dateCreated;
	/**
	 * the content of the comment
	 */
	private String comment;
	/**
	 * helper for generating id for the comment data.
	 */
	private static int idHelper = 0;
	
	/**
	 * default constructor
	 */
	public Comment(){
		comment =  new String();
		dateCreated =  new String();
	}

	/**
	 * overloaded constructor
	 * @param comment
	 * @param rank
	 * @param dateCreated
	 */
	public Comment(String comment, short rank, String dateCreated){
		this.commentId = ++idHelper;
		this.comment = comment;
		this.rank = rank;
		this.dateCreated = dateCreated;
	}

	/**
	 * returns commentID
	 * @return int
	 */
	public int getCommentId(){
		return commentId;	
	}
	

	/**
	 * sets the dateCreated
	 * @param dateCreated
	 */
	public void setDateCreated(String dateCreated){
		this.dateCreated = dateCreated;
	}
	
	
	/**
	 * get dateCreated
	 * @return String
	 */
	public String getDateCreated(){
		return dateCreated;
	}
	
	
	/**
	 * sets the rank
	 * @param rank
	 */
	public void setRank(short rank){
		this.rank = rank;
	}
	
	
	/**
	 * get the rank
	 * @return float
	 */
	public float getRank(){
		return rank;
	}
	
	
	/**
	 * sets the comment
	 * @param comment
	 */
	public void setComment(String comment){
		this.comment = comment;
	}
	
	
	/**
	 * get the comment
	 * @return String
	 */
	public String getComment(){
		return comment;
	}
	

	/* string represent the comment
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString(){
		StringBuilder sb = new StringBuilder();
		sb.append(commentId);
		sb.append(" ");
		sb.append(comment);
		sb.append(" ");
		sb.append(rank);
		sb.append(" ");
		sb.append(dateCreated);
		sb.append(" ");
		return sb.toString();
		
	}
	
	/*
	 * displays the information stored in this class
	 */
	public void display()
	{
		System.out.println(toString());
	}
}

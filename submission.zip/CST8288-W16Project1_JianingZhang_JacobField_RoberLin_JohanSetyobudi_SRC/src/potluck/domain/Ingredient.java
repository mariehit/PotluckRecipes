package potluck.domain;
/**
 * Ingredient class, holds all the information for ingredients
 * Potluck recipe project
 * CST 8288
 * March 7, 2016
 * @author Johan Setyobudi
 * @version   0.0.0
 * 
 * @since 1.8.0_65
 */

public class Ingredient {
	
	/**
	 * ingredient id
	 */
	private int id = 0;
	/**
	 * ingredient name
	 */
	private String name;
	/**
	 * measurement for ingredient
	 */
	private String measurement;
	/**
	 * helper for ingredient id
	 */
	private static int idHelper = 0;
	
	/**
	 * default constructor
	 */
	public Ingredient() {
		name = new String();
		measurement = new String();
	}
	
	
	/**
	 * constructor
	 * @param name
	 * @param measurement
	 */
	public Ingredient(String name, String measurement) {
		id = ++idHelper;
		this.name = name;
		this.measurement = measurement;
	}

	
	/**
	 * get the ingredient id
	 * @return int
	 */
	public int getIngredientId() {
		return id;
	}

	
	/**
	 * get the ingredient name
	 * @return String
	 */
	public String getName() {
		return name;
	}

	
	/**
	 * set ingredient name
	 * @param name
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * gets the measurement for ingredient
	 * @return String
	 */
	public String getMeasurement() {
		return measurement;
	}

	/**
	 * sets the measurement
	 * @param measurement
	 */
	public void setMeasurement(String measurement) {
		this.measurement = measurement;
	}
	

	/* retuns a string built using the information
	 * in this class
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		String string = new String();
		string = "Ingredient Name: " +name + " Measurement: " +measurement + "\n";
		return string;
	}
	
	/**
	 * displays the information in this class
	 */
	public void display()
	{
		System.out.println(toString());
	}
}

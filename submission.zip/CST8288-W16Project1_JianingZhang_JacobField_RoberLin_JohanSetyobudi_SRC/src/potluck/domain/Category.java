package potluck.domain;

/**
 * Category class represent the category of the recipe
 * @author Marie
 * @version   0.0.0
 * 
 * @since 1.8.0_65
 */

/*
 * holds all the information for categories
 */

public class Category {
	/**
	 * category id
	 */
	private int category_id;
	/**
	 * category name
	 */
	private CategoryName categoryName;
	
	/**
	 * constructor
	 * @param categoryName
	 */
	public Category(CategoryName categoryName) {
		this.categoryName = categoryName;
	}
	
	/**
	 * get categoryName
	 * @return CategoryName
	 */
	public CategoryName getCategoryName() {
		return categoryName;
	}
	
	/**
	 * get categoryID
	 * @return
	 */
	public int getCategory_id() {
		return category_id;
	}
	/**
	 * prints out what category it is
	 */
	public void display()
	{
		if(categoryName == CategoryName.BAKERY)
		{
			System.out.println("Category: bakery");
		}
		if(categoryName == CategoryName.MEAT)
		{
			System.out.println("Category: meat");
		}
		if(categoryName == CategoryName.VEGGIE)
		{
			System.out.println("Category: vegie");
		}
	}
}

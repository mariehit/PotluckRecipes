Please login the program with 
username: marie
password: 000000
package potluck.domain;

import java.util.ArrayList;

/**
 * The part of the delegate that defines
 * the functionality of an admin
 * @author Robert Lin, Jacob Field
 * @version   0.0.0
 * 
 * @since 1.8.0_65
 */
public class AdminBehaviour extends NormalUserBehaviour implements UserBehaviour{
	/* deletes a comment based on the index recieved
	 * @see potluck.domain.NormalUserBehaviour#deleteComment(int)
	 */
	@Override
	public void deleteComment(int index) {
		// TODO Auto-generated method stub
		
	}

	
	/* deletes a recipe based on the index recieved
	 * @see potluck.domain.NormalUserBehaviour#deleteRecipe(int)
	 */
	@Override
	public void deleteRecipe(int index) {
		RecipeDB.RECIPE_DB.deleteRecipe(index);
		
	}

	
	/* return what current type of user
	 * @see potluck.domain.NormalUserBehaviour#userBehaviour()
	 */
	@Override
	public String userBehaviour() {
		
		return "admin";
	}

}

package potluck.domain;

/**
 * an enum holding the possible category types
 * @author Marie
 * @version   0.0.0
 * 
 * @since 1.8.0_65
 */

public enum CategoryName {
	MEAT,
	VEGGIE,
	BAKERY;
		
}

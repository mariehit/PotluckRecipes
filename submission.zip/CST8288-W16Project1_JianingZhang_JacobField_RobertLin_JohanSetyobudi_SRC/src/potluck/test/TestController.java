package potluck.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.ArrayList;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import potluck.domain.Category;
import potluck.domain.CategoryName;
import potluck.domain.Controller;
import potluck.domain.Ingredient;
import potluck.domain.RecipeDB;
import potluck.domain.Tag;
/**
 * 
 * @author Marie
 *
 */
public class TestController {
	/**
	 * controller
	 */
	private Controller controller;

	/**
	 * setup before test
	 * @throws Exception
	 */
	@Before
	public void setUp() throws Exception {
		controller = new Controller();
		controller.loginController("marie", "000000");
	}

	/**
	 * clear up after test
	 * @throws Exception
	 */
	@After
	public void tearDown() throws Exception {
		controller = null;
	}
	
	/**
	 * test name setup in loginController
	 */
	@Test
	public void testLoginControllerName() {
		assertEquals("Marie", controller.getUser().getUsername());
	}
	
	
	/**
	 * test password setup in loginController
	 */
	@Test
	public void testLoginControllerPassword() {
		assertEquals("000000", controller.getUser().getPassword());
	}

	/**
	 * test create recipe
	 */
	@Test
	public void testCreateRecipePrepare() {
		controller.createRecipePrepare();
		assertNotNull(controller.getUser().getRecipeBuilder());
	}
	
	/**
	 * test add directions
	 */
	@Test
	public void testAddDirections() {
		controller.addDirections("directions");
		assertEquals("directions", controller.getUser().getRecipeBuilder().getDirections());
		
	}
	/**
	 * test add category
	 */
	@Test
	public void testAddCategory() {
		controller.addCategory(new Category(CategoryName.BAKERY));
		assertEquals(CategoryName.BAKERY, controller.getUser().getRecipeBuilder().getCategory().getCategoryName());
	}
	
	/**
	 * test add ingredients
	 */
	@Test
	public void testAddIngredients() {
		Ingredient ingredient = new Ingredient();
		ArrayList<Ingredient> ingredients = new ArrayList<>();
		ingredients.add(ingredient);
		controller.addIngredients(ingredients);
		assertNotNull(controller.getUser().getRecipeBuilder().getIngredients());
	}
	
	/**
	 * test add tags
	 */
	@Test
	public void testAddTags() {
		Tag tag = new Tag();
		ArrayList<Tag> tags = new ArrayList<>();
		tags.add(tag);
		controller.addTags(tags);
		assertNotNull(controller.getUser().getRecipeBuilder().getTags());
	}
	
	/**
	 * test create recipe
	 */
	public void testCreateRecipe() {
		controller.createRecipe();
		assertEquals(1, RecipeDB.RECIPE_DB.getRecipeList().size());
	}

	
}
